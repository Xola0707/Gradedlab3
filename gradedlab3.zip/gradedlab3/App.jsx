import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  FlatList,
  Image,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";

/*Keep all the information we need
  The big list from the internet
  The list we actually show
  What the user types
  Are we still waiting?
  Did something go wrong?
*/
export default function App() {
  const [allProducts, setAllProducts] = useState([]); 
  const [shownProducts, setShownProducts] = useState([]); 
  const [searchText, setSearchText] = useState("");  
  const [loading, setLoading] = useState(false);  
  const [error, setError] = useState(false);  

  /*This happens ONE TIME when the app starts
    We are fetching data
    Assume no errors yet
  
  */
  useEffect(() => {
    setLoading(true); 
    setError(false); 

    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json()) 
      .then((data) => {
        setAllProducts(data); 
        setShownProducts(data); 
      })
      .catch(() => {
        setError(true); 
      })
      .finally(() => {
        setLoading(false); 
      });
  }, []);

  
  useEffect(() => {
    const filtered = allProducts.filter((p) =>
      p.title.toLowerCase().includes(searchText.toLowerCase())
    );
    setShownProducts(filtered);
  }, [searchText, allProducts]);

  
  const ProductCard = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.image }} style={styles.image} />
      <Text style={styles.title} numberOfLines={2}>
        {item.title}
      </Text>
      <Text style={styles.price}>${item.price.toFixed(2)}</Text>
      <Text style={styles.category}>{item.category}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Search bar */}
      <View style={styles.searchBox}>
        <TextInput
          style={styles.searchInput}
          placeholder="Type to search products..."
          value={searchText}
          onChangeText={setSearchText}
        />
        {searchText.length > 0 && (
          <TouchableOpacity
            style={styles.clearButton}
            onPress={() => setSearchText("")}
          >
            <Text style={{ color: "#fff" }}>Clear</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* If still loading, show spinner */}
      {loading && (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#007bff" />
          <Text>Loading products...</Text>
        </View>
      )}

      {/* If something went wrong */}
      {error && !loading && (
        <View style={styles.center}>
          <Text style={{ color: "red" }}>
            Could not load products. Please try again.
          </Text>
        </View>
      )}

      {/* Show products or no results message */}
      {!loading && !error && (
        <FlatList
          data={shownProducts}
          renderItem={ProductCard}
          keyExtractor={(item) => item.id.toString()}
          numColumns={2}
          columnWrapperStyle={{ justifyContent: "space-between" }}
          ListEmptyComponent={
            <Text style={styles.center}>No products found</Text>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: "#f5f5f5" },
  searchBox: { flexDirection: "row", marginBottom: 15 },
  searchInput: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#ccc",
  },
  clearButton: {
    backgroundColor: "#007bff",
    padding: 10,
    marginLeft: 8,
    borderRadius: 8,
  },
  card: {
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    flex: 1,
    margin: 5,
    elevation: 3,
  },
  image: { width: "100%", height: 120, resizeMode: "contain" },
  title: { fontWeight: "bold", fontSize: 14, marginVertical: 5 },
  price: { color: "#007bff", fontSize: 14 },
  category: { fontSize: 12, color: "#666" },
  center: { alignItems: "center", justifyContent: "center", marginTop: 20 },
});